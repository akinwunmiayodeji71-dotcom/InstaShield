package com.instashield.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
